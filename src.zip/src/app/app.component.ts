import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `              
			    <search-app> </search-app>		  
           `
})
export class AppComponent { 
}
    