import { Component, OnInit } from '@angular/core';
import { Benefits } from '../services/benefits';
import { Observable } from 'rxjs';
import { ItemService } from '../services/item.service';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http'

@Component({
  selector: 'search-app',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [ItemService]
})
export class SearchComponent implements OnInit {
  benefits: Observable<Benefits>;
  searchInput = '';
  temp: any;
  id: string;
  serviceData: any = [];
  result: any;
  item: any = "";
  valueForKey: any;
  showTable: boolean = false
  toIterate: any = [];
  objectKeys = Object.keys;
  constructor(private itemService: ItemService, private http: Http) { }
  objectType: boolean;
  arrayOfObjectType: boolean;
  typeOfValue: any;
  lengthOfKeys: any;
  dataList: any = [];
  output: any = [];
  ngOnInit(): void {
    // this.getStoreItems();
  }

  searchEntries() {
    let searchInput = this.searchInput;
    console.log("Hello" + this.searchInput);
    this.showTable = true;
    this.itemService.searchEntries(this.searchInput).subscribe(data => {
      if (data) {
        this.serviceData = data;
        this.item = JSON.stringify(this.serviceData);
        console.log(this.item);
        // this.dataList.push(this.serviceData);
        console.log("serviceDataArray" + this.serviceData["netWorkType"]);
        // console.log("dataList" + this.dataList);
        // this.id = data._id;
        this.getKeysDuplicate(data);
      }
    })
  }
  getKeysDuplicate(obj) {
    const keyify = (obj, prefix = '') =>
      Object.keys(obj).reduce((res, el) => {
        if (Array.isArray(obj[el])) {
          return res;
        } else if (typeof obj[el] === 'object' && obj[el] !== null) {
          return [...res, ...keyify(obj[el], prefix + el + '.')];
        } else {
          return [...res, prefix + el];
        }
      }, []);
    this.output = keyify(obj);
    console.log(this.output);
  }

  private getValuesUsingArray(key, networkType, benefit) {
    this.valueForKey = this.serviceData[networkType][benefit][key];
  }
  getKeys(obj) {
    console.log("find" + obj);
    console.log("getKeys" + Object.keys(obj));
    console.log("lenght" + Object.keys(obj).length);
    return Object.keys(obj);

  }
  getLengthOfKeys(obj) {
    console.log("find" + obj);
    this.lengthOfKeys = Object.keys(obj).length;
    console.log("lengthOfKeys" + this.lengthOfKeys);
    return Object.keys(obj).length;
  }

  checkType(attrValue) {
    return typeof attrValue;
  }
  getRowspanValues(obj) {
    return Object.keys(obj).length;
  }
  getValueUsingKey(key, obj) {
    return obj[key];
  }

  splitObjectName(obj, startValue, splitValue) {
    const result = this.output[startValue].split('.');
    return result[splitValue];
  }

  findValue(value) {
    const result = this.output.find(f => f === value) ? true : false;
    return result;
  }

}
