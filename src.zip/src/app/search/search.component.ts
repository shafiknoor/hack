import { Component, OnInit } from '@angular/core';
import { Item } from '../services/item';
import { ItemService } from '../services/item.service';
@Component({
  selector: 'search-app',
  templateUrl: './search.component.html', 
  styleUrls: ['./search.component.css'],
  providers: [ItemService]
})
export class SearchComponent implements OnInit { 
   storeItems: Item[] = [];
   searchInput = '';
   constructor(private itemService: ItemService) { }
  
   ngOnInit(): void {
       // this.getStoreItems();
   }
  
   searchEntries() {
     let searchInput = this.searchInput;
     console.log("Hello"+this.searchInput);
    this.itemService.searchEntries(this.searchInput);
    console.log("Hello");
}
   
}
    