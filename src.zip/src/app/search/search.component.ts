import { Component, OnInit } from '@angular/core';
import { Benefits } from '../services/benefits';
import { Observable } from 'rxjs';
import { ItemService } from '../services/item.service';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http'

@Component({
  selector: 'search-app',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [ItemService]
})
export class SearchComponent implements OnInit {
  benefits: Observable<Benefits>;
  searchInput = '';
  temp: any;
  id: string;
  serviceData : any;
  result : any;
  item : any = "" ;
  valueForKey : any;
  inCopay : any;
  inCoinsurance : any;
  outCopay : any;
  outCoinsurance : any;
  showTable: boolean = false
  toIterate: any = [];
  objectKeys = Object.keys;
  emergencyRoomKeys : any= [];
  emaergencyRoomValues :any = [];
  constructor(private itemService: ItemService, private http: Http) { }
  objectType : boolean;
  arrayOfObjectType : boolean;
  typeOfValue: any;
  lengthOfKeys : any;
  dataList : any =[];
  ngOnInit(): void {
    // this.getStoreItems();
  }

  searchEntries() {
    let searchInput = this.searchInput;
    console.log("Hello" + this.searchInput);
    this.showTable = true;
    this.itemService.searchEntries(this.searchInput).subscribe(data => {
      if (data) {

        console.log("id"+data._id);
        console.log("vikky"+JSON.stringify(data));
        console.log("es"+data);
        this.serviceData = data;
        this.item = JSON.stringify(data);
        this.dataList.push(this.item);
       console.log("serviceDataArray"+this.item);
       console.log("dataList"+this.dataList);
        this.id = data._id;
        this.inCopay = data["inNetwork"]["emergencyRoom"]["copay"];
        this.inCoinsurance = data["inNetwork"]["emergencyRoom"]["coinsurance"];
        this.outCoinsurance = data["inNetwork"]["emergencyRoom"]["coinsurance"];
        this.outCopay = data["inNetwork"]["emergencyRoom"]["copay"];
        this.emergencyRoomKeys= Object.keys(data["inNetwork"]["emergencyRoom"]);
        console.log("emergencyRoomKeys"+this.emergencyRoomKeys);
        this.emaergencyRoomValues= Object.values(data["inNetwork"]["emergencyRoom"]);
        console.log("emaergencyRoomValues"+this.emaergencyRoomValues);
        this.toIterate = [];
        this.toIterate.push(data);
        this.myFunction();
      }
    })
  }

  private getValuesUsingArray(key, networkType, benefit) {
		this.valueForKey = this.serviceData[networkType][benefit][key];
	}
  getKeys(obj){
    console.log("find"+obj);
    console.log("getKeys"+Object.keys(obj));
    console.log("lenght"+Object.keys(obj).length);
    return Object.keys(obj);

  }
  getLengthOfKeys(obj){
    console.log("find"+obj);
    this.lengthOfKeys = Object.keys(obj).length;
    console.log("lengthOfKeys"+this.lengthOfKeys);
    return Object.keys(obj).length;
  }
  
  checkType(attrValue)
  {
      return typeof attrValue;
  }
  getRowspanValues(obj)
  {
    return Object.keys(obj).length;
  }
  getValueUsingKey(key,obj)
  {
    return obj[key];
  }
  myFunction() {
    var myText = this.serviceData;
    console.log('tetxsda',myText)
    console.log('this.serviceData',this.serviceData);
    console.log('this.item',this.item)
    var obj = myText; //json(text to json)
    this.result =  this.createTable(obj).innerHTML;
  }	
  appendKeyInTable(key)
  {
    var attrName = key;
      console.log('key',attrName);
      var cell = document.createElement("td");
      var cellText = document.createTextNode(attrName);
      cell.appendChild(cellText);
      return cell;
  }
  
  
  appendValueInTable(attrValue)
  {
     if(typeof attrValue == 'object'&& Array.isArray(attrValue) == true)
      {
          var bodyForArray = document.getElementsByTagName("body")[0];
          var tbl2 = document.createElement("table")
          var cellForValue = document.createElement("td");
          for (var i = 0; i < attrValue.length; i++) {
            var tblBodyForArray = document.createElement("tbody");
            var rowForArray = document.createElement("tr");
            var cellForArray = document.createElement("td");
  
            var cellTextForArray = document.createTextNode(attrValue[i]);
            console.log('cellTextForArray',cellTextForArray);
            cellForArray.appendChild(cellTextForArray);
            rowForArray.appendChild(cellForArray);
            tblBodyForArray.appendChild(rowForArray);
            tbl2.appendChild(tblBodyForArray);
            bodyForArray.appendChild(tbl2);
            tbl2.setAttribute("border", "2");
          }
          console.log('bodyForArray',bodyForArray);
          cellForValue.appendChild(tbl2);
        } 
     else if(typeof attrValue == 'object' && Array.isArray(attrValue) == false)
       {
       var bodyForArray = document.getElementsByTagName("body")[0];
        var tbl2 = document.createElement("table")
        var cellForValue = document.createElement("td");
        tbl2 = this.createTable(attrValue)
        cellForValue.appendChild(tbl2);
       }
     else {
          var cellForValue = document.createElement("td");
          var cellTextForValue = document.createTextNode(attrValue);
          cellForValue.appendChild(cellTextForValue);
        }
     return cellForValue;
  }
  createTable(obj)
  {
    var body = document.getElementsByTagName("result")[0];
      var tbl = document.createElement("table");
      var tblBody = document.createElement("tbody");
      for ( var key in obj) {
        var row = document.createElement("tr");
        var cellForKey = this.appendKeyInTable(key);
        row.appendChild(cellForKey);
        var attrValue = obj[key];
        var cellForValue = this.appendValueInTable(attrValue)
        row.appendChild(cellForValue);
        tblBody.appendChild(row);
        tbl.appendChild(tblBody);
        tbl.setAttribute("border", "2");
      }
      return tbl;
    }
}
