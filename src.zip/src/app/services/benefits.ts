export class Benefits {
    _id: string;
   inNetwork = new InNetwork()
   constructor() { 
   }
}

export class InNetwork {
    emergencyRoom = new EmergencyRoom()
   constructor() { 
   }
}

export class EmergencyRoom {
    coinsurance: string;
    copay: string;
   constructor() { 
   }
}