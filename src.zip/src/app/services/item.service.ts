import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http'
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ItemService {

	errorMessage: string;
	baseUrl: string = 'http://localhost:8080/getById';
	headers = new HttpHeaders({
		'Authorization': 'my-auth-token',
		'Content-Type': 'application / json',
		'Access-Control-Allow-Origin': 'GET'
	});
	// headers: new Headers({
	// 	'Content-Type': 'application/json',
	// 	'Authorization': 'my-auth-token',
	// })
	constructor(private http: HttpClient) { }

	searchEntries(term) {
		console.log("I'm in Service Method");
		// const headers = new Headers();
		// headers.append('Access-Control-Allow-Headers', 'Content-Type');
		// headers.append('Access-Control-Allow-Methods', 'GET');
		// headers.append('Access-Control-Allow-Origin', '*');
		this.http.get(this.baseUrl + '?id=' + term, { headers: this.headers }).pipe(map(data => { })).subscribe(result => {
			console.log(result);
		});
	}

}