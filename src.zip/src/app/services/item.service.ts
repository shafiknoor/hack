import { Injectable } from '@angular/core';
import { Component } from '@angular/core';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http'
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Benefits } from './benefits';
import { throwError } from '../../../node_modules/rxjs';
import { Observable, Subject } from 'rxjs';
import { map } from "rxjs/operators";

@Injectable()
export class ItemService {
	private subject = new Subject<any>();

	errorMessage: string;
	serviceData: any = [];
	id: any;
	key: any;
	keysArray: any = [];
	valueForKey: any;
	baseUrl: string = 'http://localhost:8080/v1/benefits';
	headers = new HttpHeaders({
		'Authorization': 'my-auth-token',
		'Content-Type': 'application / json',
		'Access-Control-Allow-Origin': 'GET'
	});
	constructor(private http: HttpClient) { }
	searchEntries(term): Observable<any> {
		return this.http.get(this.baseUrl + '?id=' + term);
	}
}