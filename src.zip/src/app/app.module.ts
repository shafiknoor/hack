import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { SearchComponent } from './search/search.component';
import { AppComponent } from './app.component';
import { ItemService } from './services/item.service';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
      imports: [
            BrowserModule,
            HttpModule,
            FormsModule,
            HttpClientModule

      ],
      declarations: [
            AppComponent,
            SearchComponent
      ],
      providers: [
            ItemService
      ],
      bootstrap: [
            AppComponent
      ]
})
export class AppModule { }
