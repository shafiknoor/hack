
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "planCostSharesIndividual",
    "emergencyRoom",
    "urgentCare",
    "inPatientServices",
    "pharmacy",
    "diagnosticServices",
    "mentalBehavioralHealthBenefits",
    "diseaseManagementPrograms",
    "therapeuticsRehabiltativeServices"
})
public class InNetwork {

    @JsonProperty("planCostSharesIndividual")
    private PlanCostSharesIndividual planCostSharesIndividual;
    @JsonProperty("emergencyRoom")
    private EmergencyRoom emergencyRoom;
    @JsonProperty("urgentCare")
    private UrgentCare urgentCare;
    @JsonProperty("inPatientServices")
    private InPatientServices inPatientServices;
    @JsonProperty("pharmacy")
    private Pharmacy pharmacy;
    @JsonProperty("diagnosticServices")
    private DiagnosticServices diagnosticServices;
    @JsonProperty("mentalBehavioralHealthBenefits")
    private MentalBehavioralHealthBenefits mentalBehavioralHealthBenefits;
    @JsonProperty("diseaseManagementPrograms")
    private DiseaseManagementPrograms diseaseManagementPrograms;
    @JsonProperty("therapeuticsRehabiltativeServices")
    private TherapeuticsRehabiltativeServices therapeuticsRehabiltativeServices;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public InNetwork() {
    }

    /**
     * 
     * @param pharmacy
     * @param emergencyRoom
     * @param diseaseManagementPrograms
     * @param diagnosticServices
     * @param therapeuticsRehabiltativeServices
     * @param urgentCare
     * @param inPatientServices
     * @param planCostSharesIndividual
     * @param mentalBehavioralHealthBenefits
     */
    public InNetwork(PlanCostSharesIndividual planCostSharesIndividual, EmergencyRoom emergencyRoom, UrgentCare urgentCare, InPatientServices inPatientServices, Pharmacy pharmacy, DiagnosticServices diagnosticServices, MentalBehavioralHealthBenefits mentalBehavioralHealthBenefits, DiseaseManagementPrograms diseaseManagementPrograms, TherapeuticsRehabiltativeServices therapeuticsRehabiltativeServices) {
        super();
        this.planCostSharesIndividual = planCostSharesIndividual;
        this.emergencyRoom = emergencyRoom;
        this.urgentCare = urgentCare;
        this.inPatientServices = inPatientServices;
        this.pharmacy = pharmacy;
        this.diagnosticServices = diagnosticServices;
        this.mentalBehavioralHealthBenefits = mentalBehavioralHealthBenefits;
        this.diseaseManagementPrograms = diseaseManagementPrograms;
        this.therapeuticsRehabiltativeServices = therapeuticsRehabiltativeServices;
    }

    @JsonProperty("planCostSharesIndividual")
    public PlanCostSharesIndividual getPlanCostSharesIndividual() {
        return planCostSharesIndividual;
    }

    @JsonProperty("planCostSharesIndividual")
    public void setPlanCostSharesIndividual(PlanCostSharesIndividual planCostSharesIndividual) {
        this.planCostSharesIndividual = planCostSharesIndividual;
    }

    @JsonProperty("emergencyRoom")
    public EmergencyRoom getEmergencyRoom() {
        return emergencyRoom;
    }

    @JsonProperty("emergencyRoom")
    public void setEmergencyRoom(EmergencyRoom emergencyRoom) {
        this.emergencyRoom = emergencyRoom;
    }

    @JsonProperty("urgentCare")
    public UrgentCare getUrgentCare() {
        return urgentCare;
    }

    @JsonProperty("urgentCare")
    public void setUrgentCare(UrgentCare urgentCare) {
        this.urgentCare = urgentCare;
    }

    @JsonProperty("inPatientServices")
    public InPatientServices getInPatientServices() {
        return inPatientServices;
    }

    @JsonProperty("inPatientServices")
    public void setInPatientServices(InPatientServices inPatientServices) {
        this.inPatientServices = inPatientServices;
    }

    @JsonProperty("pharmacy")
    public Pharmacy getPharmacy() {
        return pharmacy;
    }

    @JsonProperty("pharmacy")
    public void setPharmacy(Pharmacy pharmacy) {
        this.pharmacy = pharmacy;
    }

    @JsonProperty("diagnosticServices")
    public DiagnosticServices getDiagnosticServices() {
        return diagnosticServices;
    }

    @JsonProperty("diagnosticServices")
    public void setDiagnosticServices(DiagnosticServices diagnosticServices) {
        this.diagnosticServices = diagnosticServices;
    }

    @JsonProperty("mentalBehavioralHealthBenefits")
    public MentalBehavioralHealthBenefits getMentalBehavioralHealthBenefits() {
        return mentalBehavioralHealthBenefits;
    }

    @JsonProperty("mentalBehavioralHealthBenefits")
    public void setMentalBehavioralHealthBenefits(MentalBehavioralHealthBenefits mentalBehavioralHealthBenefits) {
        this.mentalBehavioralHealthBenefits = mentalBehavioralHealthBenefits;
    }

    @JsonProperty("diseaseManagementPrograms")
    public DiseaseManagementPrograms getDiseaseManagementPrograms() {
        return diseaseManagementPrograms;
    }

    @JsonProperty("diseaseManagementPrograms")
    public void setDiseaseManagementPrograms(DiseaseManagementPrograms diseaseManagementPrograms) {
        this.diseaseManagementPrograms = diseaseManagementPrograms;
    }

    @JsonProperty("therapeuticsRehabiltativeServices")
    public TherapeuticsRehabiltativeServices getTherapeuticsRehabiltativeServices() {
        return therapeuticsRehabiltativeServices;
    }

    @JsonProperty("therapeuticsRehabiltativeServices")
    public void setTherapeuticsRehabiltativeServices(TherapeuticsRehabiltativeServices therapeuticsRehabiltativeServices) {
        this.therapeuticsRehabiltativeServices = therapeuticsRehabiltativeServices;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("planCostSharesIndividual", planCostSharesIndividual).append("emergencyRoom", emergencyRoom).append("urgentCare", urgentCare).append("inPatientServices", inPatientServices).append("pharmacy", pharmacy).append("diagnosticServices", diagnosticServices).append("mentalBehavioralHealthBenefits", mentalBehavioralHealthBenefits).append("diseaseManagementPrograms", diseaseManagementPrograms).append("therapeuticsRehabiltativeServices", therapeuticsRehabiltativeServices).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(pharmacy).append(emergencyRoom).append(additionalProperties).append(diseaseManagementPrograms).append(diagnosticServices).append(therapeuticsRehabiltativeServices).append(urgentCare).append(inPatientServices).append(planCostSharesIndividual).append(mentalBehavioralHealthBenefits).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InNetwork) == false) {
            return false;
        }
        InNetwork rhs = ((InNetwork) other);
        return new EqualsBuilder().append(pharmacy, rhs.pharmacy).append(emergencyRoom, rhs.emergencyRoom).append(additionalProperties, rhs.additionalProperties).append(diseaseManagementPrograms, rhs.diseaseManagementPrograms).append(diagnosticServices, rhs.diagnosticServices).append(therapeuticsRehabiltativeServices, rhs.therapeuticsRehabiltativeServices).append(urgentCare, rhs.urgentCare).append(inPatientServices, rhs.inPatientServices).append(planCostSharesIndividual, rhs.planCostSharesIndividual).append(mentalBehavioralHealthBenefits, rhs.mentalBehavioralHealthBenefits).isEquals();
    }

}
