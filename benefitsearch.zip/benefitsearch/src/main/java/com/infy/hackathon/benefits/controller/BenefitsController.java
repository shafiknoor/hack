package com.infy.hackathon.benefits.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.comprehend.AmazonComprehend;
import com.amazonaws.services.comprehend.AmazonComprehendClientBuilder;
import com.amazonaws.services.comprehend.model.DetectKeyPhrasesRequest;
import com.amazonaws.services.comprehend.model.DetectKeyPhrasesResult;
import com.amazonaws.services.comprehend.model.KeyPhrase;
import com.infy.hackathon.benefits.PlanBenefits;
import com.infy.hackathon.benefits.repository.BenefitsRepository;
import com.infy.hackathon.util.BenfitsConstants;

@RestController
public class BenefitsController {

    @Autowired
    BenefitsRepository benefitsRepository;

    @RequestMapping(value="/v1/benefits" , method=RequestMethod.GET)
    public ResponseEntity<PlanBenefits> getTodoById(@RequestParam("id") String id) {
    	String text = id;//"What will be my copay for Emergency room on plan INFY IL Choice Plus Silver";
    	String planId="";
        // Create credentials using a provider chain. For more information, see
        // https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html
        AWSCredentialsProvider awsCreds = DefaultAWSCredentialsProviderChain.getInstance();//new AWSCredentialsProvider("AKIAIIS2QF3R6ZGFG2EQ", "dCvsH6wwhyaUsL1v+Ex9/HwwD0+GgeiXMCBIt9Q+");
 
        AmazonComprehend comprehendClient =
            AmazonComprehendClientBuilder.standard()
                                         .withCredentials(awsCreds)
                                         .withRegion(Regions.US_EAST_2)
                                         .build();
                                         
        // Call detectKeyPhrases API     
        DetectKeyPhrasesRequest detectKeyPhrasesRequest = new DetectKeyPhrasesRequest().withText(text)
                                                                                       .withLanguageCode("en");
        DetectKeyPhrasesResult detectKeyPhrasesResult = comprehendClient.detectKeyPhrases(detectKeyPhrasesRequest);
        //detectKeyPhrasesResult.getKeyPhrases().forEach(System.out::println);
        for(KeyPhrase keyPhrase:detectKeyPhrasesResult.getKeyPhrases()) {
        	if(keyPhrase.getText()!=null) {
        		if(keyPhrase.getText().contains("INF")) {
        			planId=keyPhrase.getText();
        			planId = BenfitsConstants.plantBenifitsInfo.get(planId);
        			break;
        		}
        	}
        }
        if(planId == null) {
        	planId = "INFILAdvantageGoldHMO 5000/0.5";
        }
        
        return benefitsRepository.findById(planId)
                .map(todo -> ResponseEntity.ok().body(todo))
                .orElse(ResponseEntity.notFound().build());
    }

    
}