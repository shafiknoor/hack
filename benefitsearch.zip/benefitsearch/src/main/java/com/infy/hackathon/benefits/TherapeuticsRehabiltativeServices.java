
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "acupunctureCostSharing",
    "acupunctureVisitsLimit",
    "oTPTSTCostSharing",
    "oTPTSTVisitsLimit",
    "chiroCostSharing",
    "chiroVisitsLimit"
})
public class TherapeuticsRehabiltativeServices {

    @JsonProperty("acupunctureCostSharing")
    private Double acupunctureCostSharing;
    @JsonProperty("acupunctureVisitsLimit")
    private Double acupunctureVisitsLimit;
    @JsonProperty("oTPTSTCostSharing")
    private Double oTPTSTCostSharing;
    @JsonProperty("oTPTSTVisitsLimit")
    private Double oTPTSTVisitsLimit;
    @JsonProperty("chiroCostSharing")
    private Double chiroCostSharing;
    @JsonProperty("chiroVisitsLimit")
    private Double chiroVisitsLimit;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public TherapeuticsRehabiltativeServices() {
    }

    /**
     * 
     * @param acupunctureCostSharing
     * @param oTPTSTVisitsLimit
     * @param acupunctureVisitsLimit
     * @param chiroVisitsLimit
     * @param chiroCostSharing
     * @param oTPTSTCostSharing
     */
    public TherapeuticsRehabiltativeServices(Double acupunctureCostSharing, Double acupunctureVisitsLimit, Double oTPTSTCostSharing, Double oTPTSTVisitsLimit, Double chiroCostSharing, Double chiroVisitsLimit) {
        super();
        this.acupunctureCostSharing = acupunctureCostSharing;
        this.acupunctureVisitsLimit = acupunctureVisitsLimit;
        this.oTPTSTCostSharing = oTPTSTCostSharing;
        this.oTPTSTVisitsLimit = oTPTSTVisitsLimit;
        this.chiroCostSharing = chiroCostSharing;
        this.chiroVisitsLimit = chiroVisitsLimit;
    }

    @JsonProperty("acupunctureCostSharing")
    public Double getAcupunctureCostSharing() {
        return acupunctureCostSharing;
    }

    @JsonProperty("acupunctureCostSharing")
    public void setAcupunctureCostSharing(Double acupunctureCostSharing) {
        this.acupunctureCostSharing = acupunctureCostSharing;
    }

    @JsonProperty("acupunctureVisitsLimit")
    public Double getAcupunctureVisitsLimit() {
        return acupunctureVisitsLimit;
    }

    @JsonProperty("acupunctureVisitsLimit")
    public void setAcupunctureVisitsLimit(Double acupunctureVisitsLimit) {
        this.acupunctureVisitsLimit = acupunctureVisitsLimit;
    }

    @JsonProperty("oTPTSTCostSharing")
    public Double getOTPTSTCostSharing() {
        return oTPTSTCostSharing;
    }

    @JsonProperty("oTPTSTCostSharing")
    public void setOTPTSTCostSharing(Double oTPTSTCostSharing) {
        this.oTPTSTCostSharing = oTPTSTCostSharing;
    }

    @JsonProperty("oTPTSTVisitsLimit")
    public Double getOTPTSTVisitsLimit() {
        return oTPTSTVisitsLimit;
    }

    @JsonProperty("oTPTSTVisitsLimit")
    public void setOTPTSTVisitsLimit(Double oTPTSTVisitsLimit) {
        this.oTPTSTVisitsLimit = oTPTSTVisitsLimit;
    }

    @JsonProperty("chiroCostSharing")
    public Double getChiroCostSharing() {
        return chiroCostSharing;
    }

    @JsonProperty("chiroCostSharing")
    public void setChiroCostSharing(Double chiroCostSharing) {
        this.chiroCostSharing = chiroCostSharing;
    }

    @JsonProperty("chiroVisitsLimit")
    public Double getChiroVisitsLimit() {
        return chiroVisitsLimit;
    }

    @JsonProperty("chiroVisitsLimit")
    public void setChiroVisitsLimit(Double chiroVisitsLimit) {
        this.chiroVisitsLimit = chiroVisitsLimit;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("acupunctureCostSharing", acupunctureCostSharing).append("acupunctureVisitsLimit", acupunctureVisitsLimit).append("oTPTSTCostSharing", oTPTSTCostSharing).append("oTPTSTVisitsLimit", oTPTSTVisitsLimit).append("chiroCostSharing", chiroCostSharing).append("chiroVisitsLimit", chiroVisitsLimit).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(acupunctureCostSharing).append(oTPTSTVisitsLimit).append(acupunctureVisitsLimit).append(additionalProperties).append(chiroVisitsLimit).append(chiroCostSharing).append(oTPTSTCostSharing).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TherapeuticsRehabiltativeServices) == false) {
            return false;
        }
        TherapeuticsRehabiltativeServices rhs = ((TherapeuticsRehabiltativeServices) other);
        return new EqualsBuilder().append(acupunctureCostSharing, rhs.acupunctureCostSharing).append(oTPTSTVisitsLimit, rhs.oTPTSTVisitsLimit).append(acupunctureVisitsLimit, rhs.acupunctureVisitsLimit).append(additionalProperties, rhs.additionalProperties).append(chiroVisitsLimit, rhs.chiroVisitsLimit).append(chiroCostSharing, rhs.chiroCostSharing).append(oTPTSTCostSharing, rhs.oTPTSTCostSharing).isEquals();
    }

}
