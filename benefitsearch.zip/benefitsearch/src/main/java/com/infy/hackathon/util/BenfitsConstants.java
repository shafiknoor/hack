package com.infy.hackathon.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class BenfitsConstants {
	
	public static Map<String,String> plantBenifitsInfo;
	
	static {
		if(plantBenifitsInfo==null) {
			plantBenifitsInfo=new LinkedHashMap<>();
			plantBenifitsInfo.put("INF IL Choice Plus Silver PPO", "INFILChoice PlusSilverPPO 1100/0.8");
			plantBenifitsInfo.put("INF IL Care Plus Gold HMO", "INFILCare PlusGoldHMO 2000/1");
			plantBenifitsInfo.put("INF NY Choice Plus Silver HMO", "INFNYChoice PlusSilverHMO 2500/0.2");
			plantBenifitsInfo.put("INF IL Advantage Gold HMO", "INFILAdvantageGoldHMO 5000/0.5");
			plantBenifitsInfo.put("INF IL Advantage Silver PPO", "INFILAdvantageSilverPPO 7500/0.5");
			plantBenifitsInfo.put("INF IL Advantage Bronze PPO", "INFILAdvantageBronzePPO 500/0.8");
			
			
			plantBenifitsInfo.put("INF IL Advantage Platinum PPO", "INFILAdvantagePlatinumPPO 1200/0.9");
			plantBenifitsInfo.put("INF OK Care Plus Gold PPO", "INFOKCare PlusGoldPPO 5000/0.8");
			plantBenifitsInfo.put("INF OK Choice Plus Silver PPO", "INFOKChoice PlusSilverPPO 7500/0.5");
			
			
		}
	}

}
