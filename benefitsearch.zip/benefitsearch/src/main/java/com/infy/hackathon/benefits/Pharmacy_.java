
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "genericDrugCopay",
    "formularyDrugCopay",
    "rxDeductibleintegeratedwithMedical"
})
public class Pharmacy_ {

    @JsonProperty("genericDrugCopay")
    private Double genericDrugCopay;
    @JsonProperty("formularyDrugCopay")
    private Double formularyDrugCopay;
    @JsonProperty("rxDeductibleintegeratedwithMedical")
    private String rxDeductibleintegeratedwithMedical;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Pharmacy_() {
    }

    /**
     * 
     * @param formularyDrugCopay
     * @param genericDrugCopay
     * @param rxDeductibleintegeratedwithMedical
     */
    public Pharmacy_(Double genericDrugCopay, Double formularyDrugCopay, String rxDeductibleintegeratedwithMedical) {
        super();
        this.genericDrugCopay = genericDrugCopay;
        this.formularyDrugCopay = formularyDrugCopay;
        this.rxDeductibleintegeratedwithMedical = rxDeductibleintegeratedwithMedical;
    }

    @JsonProperty("genericDrugCopay")
    public Double getGenericDrugCopay() {
        return genericDrugCopay;
    }

    @JsonProperty("genericDrugCopay")
    public void setGenericDrugCopay(Double genericDrugCopay) {
        this.genericDrugCopay = genericDrugCopay;
    }

    @JsonProperty("formularyDrugCopay")
    public Double getFormularyDrugCopay() {
        return formularyDrugCopay;
    }

    @JsonProperty("formularyDrugCopay")
    public void setFormularyDrugCopay(Double formularyDrugCopay) {
        this.formularyDrugCopay = formularyDrugCopay;
    }

    @JsonProperty("rxDeductibleintegeratedwithMedical")
    public String getRxDeductibleintegeratedwithMedical() {
        return rxDeductibleintegeratedwithMedical;
    }

    @JsonProperty("rxDeductibleintegeratedwithMedical")
    public void setRxDeductibleintegeratedwithMedical(String rxDeductibleintegeratedwithMedical) {
        this.rxDeductibleintegeratedwithMedical = rxDeductibleintegeratedwithMedical;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("genericDrugCopay", genericDrugCopay).append("formularyDrugCopay", formularyDrugCopay).append("rxDeductibleintegeratedwithMedical", rxDeductibleintegeratedwithMedical).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(formularyDrugCopay).append(additionalProperties).append(genericDrugCopay).append(rxDeductibleintegeratedwithMedical).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Pharmacy_) == false) {
            return false;
        }
        Pharmacy_ rhs = ((Pharmacy_) other);
        return new EqualsBuilder().append(formularyDrugCopay, rhs.formularyDrugCopay).append(additionalProperties, rhs.additionalProperties).append(genericDrugCopay, rhs.genericDrugCopay).append(rxDeductibleintegeratedwithMedical, rhs.rxDeductibleintegeratedwithMedical).isEquals();
    }

}
