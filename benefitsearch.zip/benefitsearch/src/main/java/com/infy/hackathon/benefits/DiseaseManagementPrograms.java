
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "homeHealthCenterVisitsLimit",
    "skilledNursingFacilityVisitsLimit"
})
public class DiseaseManagementPrograms {

    @JsonProperty("homeHealthCenterVisitsLimit")
    private Double homeHealthCenterVisitsLimit;
    @JsonProperty("skilledNursingFacilityVisitsLimit")
    private Double skilledNursingFacilityVisitsLimit;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public DiseaseManagementPrograms() {
    }

    /**
     * 
     * @param skilledNursingFacilityVisitsLimit
     * @param homeHealthCenterVisitsLimit
     */
    public DiseaseManagementPrograms(Double homeHealthCenterVisitsLimit, Double skilledNursingFacilityVisitsLimit) {
        super();
        this.homeHealthCenterVisitsLimit = homeHealthCenterVisitsLimit;
        this.skilledNursingFacilityVisitsLimit = skilledNursingFacilityVisitsLimit;
    }

    @JsonProperty("homeHealthCenterVisitsLimit")
    public Double getHomeHealthCenterVisitsLimit() {
        return homeHealthCenterVisitsLimit;
    }

    @JsonProperty("homeHealthCenterVisitsLimit")
    public void setHomeHealthCenterVisitsLimit(Double homeHealthCenterVisitsLimit) {
        this.homeHealthCenterVisitsLimit = homeHealthCenterVisitsLimit;
    }

    @JsonProperty("skilledNursingFacilityVisitsLimit")
    public Double getSkilledNursingFacilityVisitsLimit() {
        return skilledNursingFacilityVisitsLimit;
    }

    @JsonProperty("skilledNursingFacilityVisitsLimit")
    public void setSkilledNursingFacilityVisitsLimit(Double skilledNursingFacilityVisitsLimit) {
        this.skilledNursingFacilityVisitsLimit = skilledNursingFacilityVisitsLimit;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("homeHealthCenterVisitsLimit", homeHealthCenterVisitsLimit).append("skilledNursingFacilityVisitsLimit", skilledNursingFacilityVisitsLimit).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(skilledNursingFacilityVisitsLimit).append(additionalProperties).append(homeHealthCenterVisitsLimit).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DiseaseManagementPrograms) == false) {
            return false;
        }
        DiseaseManagementPrograms rhs = ((DiseaseManagementPrograms) other);
        return new EqualsBuilder().append(skilledNursingFacilityVisitsLimit, rhs.skilledNursingFacilityVisitsLimit).append(additionalProperties, rhs.additionalProperties).append(homeHealthCenterVisitsLimit, rhs.homeHealthCenterVisitsLimit).isEquals();
    }

}
