
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "deductible",
    "coinsurance",
    "perVisitCopay",
    "outOfPocketMaxLimit"
})
public class PlanCostSharesIndividual {

    @JsonProperty("deductible")
    private Double deductible;
    @JsonProperty("coinsurance")
    private Double coinsurance;
    @JsonProperty("perVisitCopay")
    private Double perVisitCopay;
    @JsonProperty("outOfPocketMaxLimit")
    private Double outOfPocketMaxLimit;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public PlanCostSharesIndividual() {
    }

    /**
     * 
     * @param coinsurance
     * @param deductible
     * @param outOfPocketMaxLimit
     * @param perVisitCopay
     */
    public PlanCostSharesIndividual(Double deductible, Double coinsurance, Double perVisitCopay, Double outOfPocketMaxLimit) {
        super();
        this.deductible = deductible;
        this.coinsurance = coinsurance;
        this.perVisitCopay = perVisitCopay;
        this.outOfPocketMaxLimit = outOfPocketMaxLimit;
    }

    @JsonProperty("deductible")
    public Double getDeductible() {
        return deductible;
    }

    @JsonProperty("deductible")
    public void setDeductible(Double deductible) {
        this.deductible = deductible;
    }

    @JsonProperty("coinsurance")
    public Double getCoinsurance() {
        return coinsurance;
    }

    @JsonProperty("coinsurance")
    public void setCoinsurance(Double coinsurance) {
        this.coinsurance = coinsurance;
    }

    @JsonProperty("perVisitCopay")
    public Double getPerVisitCopay() {
        return perVisitCopay;
    }

    @JsonProperty("perVisitCopay")
    public void setPerVisitCopay(Double perVisitCopay) {
        this.perVisitCopay = perVisitCopay;
    }

    @JsonProperty("outOfPocketMaxLimit")
    public Double getOutOfPocketMaxLimit() {
        return outOfPocketMaxLimit;
    }

    @JsonProperty("outOfPocketMaxLimit")
    public void setOutOfPocketMaxLimit(Double outOfPocketMaxLimit) {
        this.outOfPocketMaxLimit = outOfPocketMaxLimit;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("deductible", deductible).append("coinsurance", coinsurance).append("perVisitCopay", perVisitCopay).append("outOfPocketMaxLimit", outOfPocketMaxLimit).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(coinsurance).append(additionalProperties).append(deductible).append(outOfPocketMaxLimit).append(perVisitCopay).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PlanCostSharesIndividual) == false) {
            return false;
        }
        PlanCostSharesIndividual rhs = ((PlanCostSharesIndividual) other);
        return new EqualsBuilder().append(coinsurance, rhs.coinsurance).append(additionalProperties, rhs.additionalProperties).append(deductible, rhs.deductible).append(outOfPocketMaxLimit, rhs.outOfPocketMaxLimit).append(perVisitCopay, rhs.perVisitCopay).isEquals();
    }

}
