
package com.infy.hackathon.benefits;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "labCopay",
    "xrayCopay"
})
public class DiagnosticServices_ {

    @JsonProperty("labCopay")
    private Double labCopay;
    @JsonProperty("xrayCopay")
    private Double xrayCopay;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public DiagnosticServices_() {
    }

    /**
     * 
     * @param xrayCopay
     * @param labCopay
     */
    public DiagnosticServices_(Double labCopay, Double xrayCopay) {
        super();
        this.labCopay = labCopay;
        this.xrayCopay = xrayCopay;
    }

    @JsonProperty("labCopay")
    public Double getLabCopay() {
        return labCopay;
    }

    @JsonProperty("labCopay")
    public void setLabCopay(Double labCopay) {
        this.labCopay = labCopay;
    }

    @JsonProperty("xrayCopay")
    public Double getXrayCopay() {
        return xrayCopay;
    }

    @JsonProperty("xrayCopay")
    public void setXrayCopay(Double xrayCopay) {
        this.xrayCopay = xrayCopay;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("labCopay", labCopay).append("xrayCopay", xrayCopay).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalProperties).append(xrayCopay).append(labCopay).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DiagnosticServices_) == false) {
            return false;
        }
        DiagnosticServices_ rhs = ((DiagnosticServices_) other);
        return new EqualsBuilder().append(additionalProperties, rhs.additionalProperties).append(xrayCopay, rhs.xrayCopay).append(labCopay, rhs.labCopay).isEquals();
    }

}
